#!/usr/bin/env bash
set -euo pipefail
mkdir -p outputs/screenshots
# The Play Store updates Google Play services in the background a few minutes after boot, and that update
# kills every app bound to it (observed killing the app mid-instrumentation). The tests use the debug billing
# fixture, not a real Play purchase, so the store app is disabled for the test emulator only.
adb shell pm disable-user --user 0 com.android.vending | tee outputs/play_store_disabled.txt || true
adb shell wm size 1080x2400
adb shell wm density 420
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
python scripts/emulator_preflight.py | tee outputs/emulator_preflight.txt
adb shell am start -W -n com.presentsoft.shogi3minutes/.MainActivity | tee outputs/launch.txt
adb exec-out screencap -p > outputs/screenshots/00_launch.png
adb shell am force-stop com.presentsoft.shogi3minutes
set +e
timeout 660s adb shell am instrument -w com.presentsoft.shogi3minutes.test/com.presentsoft.shogi3minutes.NativeSmokeTest | tee outputs/instrumentation.txt
test_status=${PIPESTATUS[0]}
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/screenshots outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/ai_benchmark.tsv outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/model_installation.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/placement_audio.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/study_analysis.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/evaluation_graph.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/study_recovery.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/native_compatibility.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/promotion_popup.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/continuous_study.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/clipboard_import.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/legal_selection.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/record_archive.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/home_settings.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/match_settings.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/test_ads.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/coffee_purchase.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/online_play.txt outputs/ || true
adb pull /sdcard/Android/data/com.presentsoft.shogi3minutes/files/move_effect_frames.txt outputs/ || true
adb shell dumpsys gfxinfo com.presentsoft.shogi3minutes > outputs/gfxinfo.txt || true
adb shell dumpsys meminfo com.presentsoft.shogi3minutes > outputs/meminfo.txt
adb logcat -d > outputs/logcat.txt
set -e
test "$test_status" -eq 0
grep -q 'PASS native instrumentation:' outputs/instrumentation.txt
grep -q 'PASS native online mode:' outputs/online_play.txt

python scripts/verify_android_ai.py | tee outputs/android_ai_verification.txt



